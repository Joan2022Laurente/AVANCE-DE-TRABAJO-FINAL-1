package com.utp.schedule_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheduleBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
